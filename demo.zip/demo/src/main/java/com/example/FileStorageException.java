package com.example;

public class FileStorageException extends RuntimeException {

	public FileStorageException(String msg) {
		// TODO Auto-generated constructor stub
		
		super(msg);
	}
	
	public FileStorageException(String msg, Throwable cause) {
		super(msg, cause);
	}
	
}
